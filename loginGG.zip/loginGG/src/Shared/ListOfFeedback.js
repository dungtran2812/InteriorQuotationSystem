export const FeedbackData = [
    {
        customerName: 'Walks',
        comment: 'Cheese',
        designStyle: 'El',
        totalCost: '600',
        dayConstruct: 'Mountain',
        rating: '4,5',
        id: 1
      },
      {
        customerName: 'Northwest',
        comment: 'Classical',
        designStyle: 'after',
        totalCost: '0935',
        dayConstruct: 'Dollar',
        rating: '4,6',
        id: 2
      },
      {
        customerName: 'seamless',
        comment: 'stick',
        designStyle: 'Fresh',
        totalCost: 571,
        dayConstruct: 'Grocery',
        rating: '4,1',
        id: 3
      },
      {
        customerName: 'national',
        comment: 'Pataca',
        designStyle: 'Omnigender',
        totalCost: '10758',
        dayConstruct: 'Northeast',
        rating: '4,0',
        id: 4
      },
      // {
      //   customerName: 'Expanded',
      //   comment: 'Alabama',
      //   designStyle: 'near',
      //   totalCost: '2624',
      //   dayConstruct: 'Implementation',
      //   rating: '4,8',
      //   id: 5
      // },
      // {
      //   customerName: 'toe',
      //   comment: 'transmitting',
      //   designStyle: 'into',
      //   totalCost: '5945',
      //   dayConstruct: 'knowledgeable',
      //   rating: '4,3',
      //   id: 6
      // }
    
  ];